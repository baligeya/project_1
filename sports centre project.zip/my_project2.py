class Sport:
    def __init__(self, name, capacity, cost_per_hour):
        self.name = name
        self.capacity = capacity
        self.cost_per_hour = cost_per_hour
        self.available_hours = []

    def __str__(self):
        return f"Sport: {self.name}, Capacity: {self.capacity}, Cost per Hour: {self.cost_per_hour}"

    def book_slot(self, hour):
        if hour not in self.available_hours:
            self.available_hours.append(hour)
            return f"{self.name} slot at {hour} booked successfully."
        else:
            return f"Sorry, {self.name} slot at {hour} is already booked."


class Player:
    def __init__(self, name, player_id, age):
        self.name = name
        self.player_id = player_id
        self.age = age

    def __str__(self):
        return f"Player: {self.name}, ID: {self.player_id}, Age: {self.age}"


class SportsCenter:
    def __init__(self):
        self.sports = []
        self.players = []

    def add_sport(self, sport):
        self.sports.append(sport)

    def add_player(self, player):
        self.players.append(player)

    def list_available_sports(self):
        return [sport.name for sport in self.sports if sport.available_hours]

    def list_booked_slots(self):
        booked_slots = []
        for sport in self.sports:
            for hour in sport.available_hours:
                booked_slots.append((sport.name, hour))
        return booked_slots

    def list_players(self):
        return [player.name for player in self.players]


if __name__ == "__main__":
    
    sport1 = Sport("Tennis", 4, 20.0)
    sport2 = Sport("Basketball", 10, 30.0)
    sport3 = Sport("Swimming", 8, 15.0)

    player1 = Player("Deo", "P001", 25)
    player2 = Player("Jane", "P002", 30)
    player3 = Player("Masai", "P003", 22)

    sports_center = SportsCenter()

    sports_center.add_sport(sport1)
    sports_center.add_sport(sport2)
    sports_center.add_sport(sport3)

    sports_center.add_player(player1)
    sports_center.add_player(player2)
    sports_center.add_player(player3)

    print("Available Sports:")
    for sport in sports_center.list_available_sports():
        print(sport)

    print(sport1.book_slot("10:00 AM"))

    print("\nBooked Slots:")
    for sport, hour in sports_center.list_booked_slots():
        print(f"{sport} - {hour}")

    print("\nPlayers:")
    for player in sports_center.list_players():
        print(player)
